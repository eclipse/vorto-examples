import os
import csv
import sys
import logging
import netifaces
import random
import paho.mqtt.client as mqtt
import datetime, threading, time
import model.functionblock.Battery as battery 
import model.functionblock.Geolocation as location 
import model.functionblock.Acceleration as acceleration 
import model.functionblock.Temperature as temperature 
import model.functionblock.MagneticStrength as magneticStrength 
import model.functionblock.Connectivity as bluetoothConnectivity 
import model.functionblock.Connectivity as lorawanConnectivity 
import model.infomodel.Traci as Traci
import model.DittoSerializer as DittoSerializer

# DEVICE CONFIG GOES HERE
tenantId = "t99b370dafe3a4f08bc35c14cd06351ba_hub"
device_password = "secret"
hub_adapter_host = "mqtt.bosch-iot-hub.com"
deviceId ="org.eclipse.vorto.normalizer:Traci"
clientId = deviceId
authId = "org.eclipse.vorto.normalizer_Traci"
certificatePath = "./iothub.crt"
ditto_topic = "org.eclipse.vorto.normalizer/Traci"

# global variable
COUNTER = 0
A_TO_B = True
running = True

# Time in seconds for simulator to run
TIME_TO_LIVE = int(os.getenv('TIME_TO_LIVE', 30))

# Period for publishing data to the MQTT broker in seconds
TIME_INTERVAL_TELEMETRY = int(os.getenv('TIME_INTERVAL_TELEMETRY', 5))

def movement():
    global COUNTER
    global A_TO_B
    global running
    
    # calculate coordinates to skip inorder to complete simulation within the defined period
    dataset_size = len(dataset)
    print("dataset_size value is: ", dataset_size)
    coordinates_to_skip = int(dataset_size / (TIME_TO_LIVE/TIME_INTERVAL_TELEMETRY))
    
    if A_TO_B:    
        if(COUNTER+coordinates_to_skip < len(dataset)):
            COUNTER += coordinates_to_skip
            print("counter value is: ", COUNTER)
        else:
            #Terminate Program
            A_TO_B = False
            sys.exit(0)
            
    else:
        if(COUNTER-coordinates_to_skip > 0):
            COUNTER -= coordinates_to_skip
        else:
            A_TO_B = True
            

# put content of csv file in list
dataset = []
with open('./location-data.csv','rt')as f:
  data = csv.reader(f)
  for row in data:
        dataset.append({
            "latitude": row[0],
            "longitude": row[1]
        })

# Timer variable for periodic function
next_call = 0

# Configuration of client ID and publish topic	
publishTopic = "telemetry/" + tenantId + "/" + deviceId

# Output relevant information for consumers of our information
print("Connecting client:    ", clientId)
print("Publishing to topic:  ", publishTopic)

# Create the MQTT client
client = mqtt.Client(clientId)

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
client.enable_logger(logger)

client.tls_set(certificatePath)

username = authId + "@" + tenantId
client.username_pw_set(username, device_password)


# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    global next_call

    if rc != 0:
        print("Connection to MQTT broker failed: " + str(rc))
        return

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.

    # BEGIN SAMPLE CODE
    client.subscribe("commands/" + tenantId + "/")
    # END SAMPLE CODE

    # Time stamp when the periodAction function shall be called again
    next_call = time.time()
    
    # Start the periodic task for publishing MQTT messages
    periodicAction()

# The function that will be executed periodically once the connection to the MQTT broker was established
def periodicAction():
    global next_call
    global A_TO_B

    ### BEGIN READING SENSOR DATA
    
    infomodel.battery.remainingCapacity = {
    	"value" : 80
    }
    infomodel.battery.value = {
    	"currentMeasured" : 80,
    	"minMeasured" : 0,
    	"maxMeasured" : 100
    }
    infomodel.battery.remainingCapacityAmpHour = 80
    
    infomodel.location.altitude = 0
    infomodel.location.latitude = dataset[COUNTER]["latitude"]
    infomodel.location.longitude = dataset[COUNTER]["longitude"]
    movement()

    infomodel.acceleration.value = {
    	"x" : random.randint(-27, 34),
    	"y" : random.randint(-39, 21),
    	"z" : random.randint(-20, 23)
    }
    infomodel.temperature.value = {
    	"currentMeasured" : random.randint(26,40),
    	"minMeasured" : 26,
    	"maxMeasured" : 40
    }
    infomodel.magneticStrength.value = {
    	"x" : random.randint(-10, 33),
    	"y" : random.randint(-23, 21),
    	"z" : random.randint(10, 73)
    }
    infomodel.bluetoothConnectivity.rssi = 0
    infomodel.bluetoothConnectivity.snr = 0
    infomodel.bluetoothConnectivity.lastSeen = 0
    infomodel.bluetoothConnectivity.status = "Disconnected"
    infomodel.lorawanConnectivity.rssi = -75
    infomodel.lorawanConnectivity.snr = 24
    infomodel.lorawanConnectivity.lastSeen = 0
    infomodel.lorawanConnectivity.status = "Connected"

    ### END READING SENSOR DATA

    # Publish payload
    publishBattery()
    publishLocation()
    publishAcceleration()
    publishTemperature()
    publishMagneticStrength()
    publishBluetoothConnectivity()
    publishLorawanConnectivity()

    # Schedule next call
    next_call = next_call + TIME_INTERVAL_TELEMETRY
    threading.Timer(next_call - time.time(), periodicAction).start()


# The functions to publish the functionblocks data
def publishBattery():
    payload = ser.serialize_functionblock("battery", infomodel.battery, ditto_topic, deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
def publishLocation():
    payload = ser.serialize_functionblock("location", infomodel.location, ditto_topic, deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
def publishAcceleration():
    payload = ser.serialize_functionblock("acceleration", infomodel.acceleration, ditto_topic, deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
def publishTemperature():
    payload = ser.serialize_functionblock("temperature", infomodel.temperature, ditto_topic, deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
def publishMagneticStrength():
    payload = ser.serialize_functionblock("magneticStrength", infomodel.magneticStrength, ditto_topic, deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
def publishBluetoothConnectivity():
    payload = ser.serialize_functionblock("bluetoothConnectivity", infomodel.bluetoothConnectivity, ditto_topic, deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
def publishLorawanConnectivity():
    payload = ser.serialize_functionblock("lorawanConnectivity", infomodel.lorawanConnectivity, ditto_topic, deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)



# Initialization of Information Model
infomodel = Traci.Traci()

# Create a serializer for the MQTT payload from the Information Model
ser = DittoSerializer.DittoSerializer()


# Blocking call that processes network traffic, dispatches callbacks and
# handles reconnecting.
# Other loop*() functions are available that give a threaded interface and a
# manual interface.
client.on_connect = on_connect

# Connect to the MQTT broker
client.connect(hub_adapter_host, 8883, 60)

client.loop_start()

while (1):
    if A_TO_B is False:
        sys.exit(0)
    else: 
        pass
