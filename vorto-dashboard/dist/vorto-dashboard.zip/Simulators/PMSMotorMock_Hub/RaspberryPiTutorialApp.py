import base64
import csv
import datetime, threading, time
import json
import logging
import netifaces
import paho.mqtt.client as mqtt
from random import randint

# DEVICE CONFIG GOES HERE
tenantId = "td32fb4cc2a5a4145a1e503871e4f468b"
device_password = "secret"
hub_adapter_host = "mqtt.bosch-iot-hub.com"
deviceId ="pmsm0815"
clientId = deviceId
authId = "little-sensor"
certificatePath = "./iothub.crt"
ditto_topic = "pmsm0815"

# put content of csv file in list
dataset = []
with open('./pmsm_temperature_data_modified.csv','rt')as f:
  data = csv.reader(f)
  for row in data:
        dataset.append({
            "ambient": row[0],
            "coolant": row[1],
            "motor_speed": row[2],
            "torque": row[3],
            "stator_yoke": row[4],
            "stator_tooth": row[5],
            "stator_winding": row[6],
            "profile_id": row[7],
        })

# Timer variable for periodic function
next_call = 0
# Period for publishing data to the MQTT broker in seconds
timePeriod = 10
# Configuration of client ID and publish topic	
publishTopic = "telemetry/" + tenantId + "/" + deviceId

# Output relevant information for consumers of our information
print("Connecting client:    ", clientId)
print("Publishing to topic:  ", publishTopic)

# Create the MQTT client
client = mqtt.Client(clientId)

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
client.enable_logger(logger)

client.tls_set(certificatePath)

username = authId + "@" + tenantId
client.username_pw_set(username, device_password)

# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    global next_call

    if rc != 0:
        print("Connection to MQTT broker failed: " + str(rc))
        return

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.

    # BEGIN SAMPLE CODE
    client.subscribe("commands/" + tenantId + "/")
    # END SAMPLE CODE

    # Time stamp when the periodAction function shall be called again
    next_call = time.time()

    
    # Start the periodic task for publishing MQTT messages
    periodicAction()

def get_id_for_attribute(attribute):
    mapping = {
        "ambient": 1,
        "coolant": 2,
        "motor_speed": 3,
        "torque": 4,
        "stator_yoke": 5,
        "stator_tooth": 6,
        "stator_winding": 7
    }

    return mapping[attribute]

# The function that will be executed periodically once the connection to the MQTT broker was established
def periodicAction():
    global next_call

    """
        Example:
        {
            profile_id: 1,
            attribute_id: 3,
            value: -1.2224282,
            timestamp: 1563356987
        }
        
        Mapping:
        1 - ambient
        2 - coolant
        3 - motor_speed
        4 - torque
        5 - stator_yoke
        6 - stator_tooth
        7 - stator_winding
    """
    data_element = dataset[randint(0, len(dataset))]
    profile_id = data_element["profile_id"]

    for attribute in data_element:
        if attribute == "profile_id":
            continue

        curr_timestamp = int(time.time())
        js_payload = {
            "profile_id": profile_id, 
            "attribute_id": get_id_for_attribute(attribute), 
            "value": data_element[attribute], 
            "timestamp": curr_timestamp
            }

        logger.info(js_payload)
        payload = base64.b64encode(json.dumps(js_payload).encode())
        # payload = json.dumps(js_payload)

        print("Publish Payload: ", payload, " to Topic: ", publishTopic)
        client.publish(publishTopic, payload)

        time.sleep(0.25)

    # Schedule next call
    next_call = next_call + timePeriod
    threading.Timer(next_call - time.time(), periodicAction).start()


# Blocking call that processes network traffic, dispatches callbacks and
# handles reconnecting.
# Other loop*() functions are available that give a threaded interface and a
# manual interface.
client.on_connect = on_connect

# Connect to the MQTT broker
client.connect(hub_adapter_host, 8883, 60)

client.loop_start()

while (1):
    pass
